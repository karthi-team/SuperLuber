<?php

namespace App\Http\Controllers\Map;

use App\Http\Controllers\Controller;
use App\Models\SalesExecutiveTimelogs;
use App\Models\SalesRepCreation;
use App\Models\ShopCreation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class TimelineController extends Controller
{
    public function timeline()
    {
        return view('Map.timeline.admin');
    }

    public function db_cmd(Request $request)
    {
        $action=$request->input('action');

        if ($action == 'filter_timeline') {

            $filter_date = $request->input('filter_date');
            $filter_from_time = $request->input('filter_from_time');
            $filter_to_time = $request->input('filter_to_time');
            $filter_sales_executive_id = $request->input('filter_sales_executive_id');
            $filter_sales_executive_status = $request->input('filter_sales_executive_status');

            $query = SalesExecutiveTimelogs::select(
                'src.id',
                'src.sales_ref_name',
                'src.image_name',
                'sales_executive_timelogs.latitude',
                'sales_executive_timelogs.langititude',
                'sales_executive_timelogs.date',
                'sales_executive_timelogs.time',
                'sales_executive_timelogs.current_status'
            )
            ->join('sales_ref_creation as src', 'src.id', '=', 'sales_executive_timelogs.sales_executive_id');

            if ($filter_date != '') {
                $query->where('sales_executive_timelogs.date', $filter_date);
            }
            if ($filter_from_time != '' && $filter_to_time != '') {
                if($filter_from_time != $filter_to_time){
                    $query->whereBetween('sales_executive_timelogs.time', [$filter_from_time, $filter_to_time]);
                }
            }
            if ($filter_sales_executive_id != '') {
                $query->where('sales_executive_timelogs.sales_executive_id', $filter_sales_executive_id);
            }
            if ($filter_sales_executive_status != '') {
                $query->where('sales_executive_timelogs.current_status', $filter_sales_executive_status);
            }

            $query->orderBy('sales_executive_timelogs.id', 'asc');
            $sales_executive_timelogs = $query->get();

            return response()->json($sales_executive_timelogs);
        }
        else if ($action == 'get_sales_executive') {

            $filter_date = $request->input('filter_date');

            $sales_rep_name = SalesRepCreation::select('sales_ref_creation.id', 'sales_ref_creation.sales_ref_name')
            ->join('sales_executive_timelogs', 'sales_ref_creation.id', '=', 'sales_executive_timelogs.sales_executive_id')
            ->whereIn('sales_executive_timelogs.id', function($query) {
                $query->select(DB::raw('MAX(id)'))
                    ->from('sales_executive_timelogs')
                    ->groupBy('sales_executive_id');
            })
            ->where('sales_executive_timelogs.date', $filter_date)
            ->orderBy('sales_executive_timelogs.id', 'asc')
            ->get();

            return response()->json($sales_rep_name);

        } elseif ($action == 'timeline_shop_list') {

            $shop_list = ShopCreation::select('shop_creation.id as shop_id', 'shop_creation.shop_name', 'dealer_creation.dealer_name', 'shop_creation.mobile_no', 'shops_type.shops_type', 'area_creation.area_name',  DB::raw('COALESCE(shop_creation.address, "-") as address'), 'shop_creation.latitude', 'shop_creation.longitude', 'shop_creation.image_name')
            ->join('shops_type', 'shops_type.id', '=', 'shop_creation.shop_type_id')
            ->join('area_creation', 'area_creation.id', '=', 'shop_creation.beats_id')
            ->join('dealer_creation', 'dealer_creation.id', '=', 'shop_creation.dealer_id')
            ->where('shop_creation.latitude', '!=', '')
            ->where('shop_creation.longitude', '!=', '')
            ->orderBy('shop_creation.id')
            ->get();

            return response()->json($shop_list);

        }
    }
}
