<?php

namespace App\Http\Controllers\Reports;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\Entry\SalesOrderDeliveryMain;
use App\Models\Entry\SalesOrderDeliverySub;
use App\Models\SalesRepCreation;
use App\Models\DealerCreation;
use App\Models\ItemCreation;
use App\Models\MarketManagerCreation;
use Carbon\Carbon;
class ItemSalesPendingMonthWiseReportController extends Controller
{
    public function item_sales_pending_month_wise_report()
    {
        $sales_rep_creation = SalesRepCreation::select('id', 'sales_ref_name')
        ->where('sales_ref_name', '!=', '')
        ->orderBy('sales_ref_name')
        ->get();

        $item_creation = ItemCreation::select('id', 'item_name')->where(function ($query) {
            $query->where('delete_status', '0')->orWhereNull('delete_status');
        })->orderBy('id')->get();

        $manager_creation=MarketManagerCreation::select('id','manager_name')->where('delete_status', '0')->orWhereNull('delete_status')->orderBy('manager_no')->get();

        return view('Reports.item_sales_pending_month_wise_report.admin',[
        'sales_rep_creation'=>$sales_rep_creation, 'manager_creation'=>$manager_creation,
        'item_creation'=>$item_creation

        ]);
    }
    public function retrieve($from_date, $to_date, $sales_ref_id, $item_id, $manager_id,$dealer_id)
    {
        if (empty($from_date)) {
            $currentDay = date('d');
            $currentMonth = date('m');
            $currentYear = date('Y');
            $from_date = $currentYear . '-' . $currentMonth . '-'.$currentDay;
            $to_date = $currentYear . '-' . $currentMonth . '-'.'31';

        }

        $dealerQuery = DB::table('sales_order_delivery_main_c as sodmc')
        ->leftJoin('sales_order_delivery_sublist_c as sodsc', 'sodmc.id', '=', 'sodsc.sales_order_main_id')
        ->leftJoin('sales_ref_creation as src', 'src.id', '=', 'sodmc.sales_exec')
        ->leftJoin('market_manager_creation as mmc', 'mmc.id', '=', 'src.manager_id')
        ->leftJoin('dealer_creation as dc', 'dc.id', '=', 'sodmc.dealer_creation_id')
        ->leftJoin('item_creation as ic', 'ic.id', '=', 'sodsc.item_creation_id')
        ->whereBetween('sodsc.order_date_sub', [$from_date, $to_date])
        ->when($sales_ref_id, function ($query) use ($sales_ref_id) {
            return $query->where('sodmc.sales_exec', $sales_ref_id);
        })
        ->when($item_id, function ($query) use ($item_id) {
            return $query->where('sodsc.item_creation_id', $item_id);
        })
        ->when($manager_id, function ($query) use ($manager_id) {
            return $query->where('mmc.id', $manager_id);
        })
        ->when($dealer_id, function ($query) use ($dealer_id) {
            return $query->where('sodmc.dealer_creation_id', $dealer_id);
        })
        ->groupBy('sodmc.dealer_creation_id')
        ->select('sodmc.dealer_creation_id', DB::raw('MAX(sodmc.sales_exec) as sales_exec'), DB::raw('MAX(sodsc.item_creation_id) as item_creation_id'))
        ->get();



        return $dealerQuery;
    }

    public function retrieve1($sales_ref_id,$salesExecArray,$manager_id)
{

        $sales_name = SalesRepCreation::select('id', 'sales_ref_name')->where(function ($query) use ($salesExecArray) {
            $query->whereIn('id', $salesExecArray)
                ->orWhereNull('delete_status', '0')
                ->orWhereNull('delete_status');
        })->orderBy('sales_ref_name');

        if (!empty($manager_id)) {
            $sales_name->where('manager_id', '=', $manager_id);
        }

        if (!empty($sales_ref_id)) {
            $sales_name->where('id', '=', $sales_ref_id);
        }
        $sales_name->whereIn('id', $salesExecArray);
        $sales_name1 = $sales_name->get();

        return $sales_name1;

}

public function sales_dealer($sales_ref_id,$dealer_id,$salesDealerArray)
{

    $dealer_name1 = DealerCreation::select('id','sales_rep_id', 'dealer_name', )->where(function ($query) {
        $query->where('delete_status', '0')->orWhereNull('delete_status');
    })->orderBy('dealer_name');


    if (!empty($sales_ref_id)) {
        $dealer_name1->where('sales_rep_id', $sales_ref_id);
    }

    if (!empty($dealer_id)) {
        $dealer_name1->where('id', $dealer_id);
    }

    $dealer_name1->whereIn('id', $salesDealerArray);

    $dealer_name = $dealer_name1->get();

        return $dealer_name;

}

public function retrieve2($item_id, $salesItemListArray)
{

    $item_name=ItemCreation::select('item_creation.id','item_creation.item_name','item_creation.short_code','group_creation.group_name')
    ->join('group_creation', 'group_creation.id', '=', 'item_creation.group_id')
    ->whereIn('item_creation.id', $salesItemListArray)
    ->where(function($query){
        $query->where('item_creation.delete_status', '0')->orWhereNull('item_creation.delete_status');
    })
    ->orderBy('item_creation.id');
    if (!empty($item_id)) {
        $item_name->where('item_creation.id', '=', $item_id);
    }
    $item_name1 = $item_name->get();

   return $item_name1;

}

public function retrieve3($from_date, $to_date, $sales_ref_id, $item_id, $manager_id,$dealer_id)
    {
        if (empty($from_date)) {
            $currentDay = date('d');
            $currentMonth = date('m');
            $currentYear = date('Y');
            $from_date = $currentYear . '-' . $currentMonth . '-'.$currentDay;
            $to_date = $currentYear . '-' . $currentMonth . '-'.'31';

        }
            $sales_order_deli_t = DB::table('sales_order_delivery_sublist_c as sods')
            ->leftJoin('sales_order_delivery_main_c as sodm', 'sods.sales_order_main_id', '=', 'sodm.id')
            ->leftJoin('item_creation as ic', 'sods.item_creation_id', '=', 'ic.id')
            ->leftJoin('dealer_creation as dc', 'dc.id', '=', 'sodm.dealer_creation_id')
            ->leftJoin('sales_ref_creation as src', 'src.id', '=', 'sodm.sales_exec')

            ->leftJoin('market_manager_creation as mmc', 'mmc.id', '=', 'src.manager_id')
            ->groupBy('ic.id')


            ->orderBy('ic.id')
            ->select('ic.id as item_id',DB::raw('SUM(sods.order_quantity) as total_order_quantity'), DB::raw('SUM(sods.balance_quantity) as total_balance_quantity'))
            ->where(function($query){
                $query->where('sodm.delete_status', '0')->orWhereNull('sodm.delete_status');
            })
            ->where(function($query){
                $query->where('sods.delete_status', '0')->orWhereNull('sods.delete_status');
            });

        if (!empty($from_date)) {
            $sales_order_deli_t->where('sodm.entry_date', '>=', $from_date);
        }

        if (!empty($to_date)) {
            $sales_order_deli_t->where('sodm.entry_date', '<=', $to_date);
        }

        if (!empty($sales_ref_id)) {
            $sales_order_deli_t->where('sodm.sales_exec', '=', $sales_ref_id);
        }

        if (!empty($dealer_id)) {
            $sales_order_deli_t->where('sodm.dealer_creation_id', '=', $dealer_id);
        }

        if (!empty($item_id)) {
            $sales_order_deli_t->where('sods.item_creation_id', '=', $item_id);
        }

        if (!empty($manager_id)) {
            $sales_order_deli_t->where('src.manager_id', '=', $manager_id);
        }

        $sales_order_deli_t->where(function ($query) {
            $query->where('sodm.delete_status', '0')->orWhereNull('sodm.delete_status');
        });

        $sales_order_deli_t->where(function ($query) {
            $query->where('sods.delete_status', '0')->orWhereNull('sods.delete_status');
        });

        $sales_order_deli_t1 = $sales_order_deli_t->get();
      return $sales_order_deli_t1;

    }

    public function db_cmd(Request $request)
    {
        $action=$request->input('action');
        if($action=='retrieve')
        {
            $from = $request->input('from_date');
            $from_date = $request->input('from_date');
            $to_date = $request->input('to_date');
            $ref_id = $request->input('sales_ref_id');
            $dealer_id = $request->input('dealer_id');
            $item_id = $request->input('item_id');
            $manager = $request->input('manager_id');

            $query_1 = DB::table('sales_order_delivery_main_c as sodmc')
            ->leftJoin('sales_order_delivery_sublist_c as sodsc', 'sodmc.id', '=', 'sodsc.sales_order_main_id')
            ->select(
                DB::raw('SUM(sodsc.order_quantity) as total_order_quantity'),
                DB::raw('SUM(sodsc.balance_quantity) as total_balance_quantity'),
                'sodsc.item_creation_id',
                'sodmc.dealer_creation_id'
            )
            ->where(function($query){
                $query->where('sodmc.delete_status', '0')->orWhereNull('sodmc.delete_status');
            })
            ->where(function($query){
                $query->where('sodsc.delete_status', '0')->orWhereNull('sodsc.delete_status');
            })
            ->groupBy('sodsc.item_creation_id', 'sodmc.dealer_creation_id');

        if (!empty($from_date) && !empty($to_date)) {
            $query_1->whereBetween('sodsc.order_date_sub', [$from_date, $to_date]);
        }

        if (!empty($ref_id)) {
            $query_1->where('sodmc.sales_exec', $ref_id);
        }

        if (!empty($dealer_id)) {
            $query_1->where('sodmc.dealer_creation_id', $dealer_id);
        }

        if (!empty($item_id)) {
            $query_1->where('sodsc.item_creation_id', $item_id);
        }

        $lokie = $query_1->get();


// return $dealer_id;

            $item_sales_pending_month_wise_report = $this->retrieve($request->input('from_date'),$request->input('to_date'),$request->input('sales_ref_id'),$request->input('item_id'),$request->input('manager_id'),$request->input('dealer_id'));
            if (empty(($request->input('from_date')))) {
                $currentDay = date('d');
                $currentMonth = date('m');
                $currentYear = date('Y');
                $from_date = $currentYear . '-' . $currentMonth . '-'.$currentDay;
                $to_date = $currentYear . '-' . $currentMonth . '-'.
                '31';

            }else{
                $from_date =  $request->input('from_date');
                $to_date =  $request->input('to_date');
            }

            $salesExecs = DB::table('sales_order_delivery_main_c')
            ->select('sales_exec');
            if (!empty($from_date)) {
                $salesExecs->where('entry_date', '>=', $from_date);
            }

            if (!empty($to_date)) {
                $salesExecs->where('entry_date', '<=', $to_date);
            }
            $salesExecs1 = $salesExecs->get();

            $salesExecArray = $salesExecs1->pluck('sales_exec')->toArray();

            $salesDealer = DB::table('sales_order_delivery_main_c')
            ->select('dealer_creation_id')
            ->groupBy('sales_exec','dealer_creation_id');
            if (!empty($from_date)) {
                $salesDealer->where('entry_date', '>=', $from_date);
            }

            if (!empty($to_date)) {
                $salesDealer->where('entry_date', '<=', $to_date);
            }
            $salesDealer1 = $salesDealer->get();

            $salesDealerArray = $salesDealer1->pluck('dealer_creation_id')->toArray();

            $salesItemList = DB::table('sales_order_delivery_sublist_c')
            ->select('item_creation_id')
            ->groupBy('item_creation_id');
            if (!empty($from_date)) {
                $salesItemList->where('order_date_sub', '>=', $from_date);
            }

            if (!empty($to_date)) {
                $salesItemList->where('order_date_sub', '<=', $to_date);
            }
            $salesItemList1 = $salesItemList->get();

            $salesItemListArray = $salesItemList1->pluck('item_creation_id')->toArray();

            $sales_rep_creation = $this->retrieve1($request->input('sales_ref_id'),$salesExecArray,$request->input('manager_id'));

            $sales_dealer_creation = $this->sales_dealer($request->input('sales_ref_id'),$request->input('dealer_id'),$salesDealerArray);

            $item_creation = $this->retrieve2($request->input('item_id'), $salesItemListArray);

            $item_sales_total = $this->retrieve3($request->input('from_date'),$request->input('to_date'),$request->input('sales_ref_id'),$request->input('item_id'),$request->input('manager_id'),$request->input('dealer_id'));

            if (empty($from_date)) {
                $currentDay = date('d');
                $currentMonth = date('m');
                $currentYear = date('Y');
                $from_date = $currentYear . '-' . $currentMonth . '-'.$currentDay;
            }
            $arr=[];

            foreach($item_sales_pending_month_wise_report as $iem_get_all){
                $dealer_id = $iem_get_all->dealer_creation_id;
                $sales_name = $iem_get_all->sales_exec;

                $get_dealer=DealerCreation::find($dealer_id);
                $dealer_names =$get_dealer->dealer_name;
                $get_sales = SalesRepCreation::find($sales_name);
                $sales_ref = $get_sales->sales_ref_name;
                $finally = [
                    'dealer_names'=>$dealer_names,
                    'sales_ref'=>$sales_ref
                ];
                $arr[]=$finally;
            }

//    return $from_date;
            return view('Reports.item_sales_pending_month_wise_report.list',['item_creation' => $item_creation,'sales_order_deli' => $item_sales_pending_month_wise_report, 'sales_rep_creation' => $sales_rep_creation,'sales_dealer_creation' => $sales_dealer_creation, 'from_date' => $from_date, 'item_sales_total' => $item_sales_total,'salesExecArray' => $salesExecArray,
            'lokie'=>$lokie,
            'arr'=>$arr,
            'manager'=>$from

            ]);

        }else if ($action == 'getSalesRef') {


            $manager_id= $request->input('manager_id');

            $sales_ref_name = SalesRepCreation::select('id', 'sales_ref_name')->where('manager_id', $manager_id)->where(function ($query) {
                $query->where('delete_status', '0')->orWhereNull('delete_status');
            })->orderBy('sales_ref_name')->get();
            return response()->json($sales_ref_name);
        }
        else if ($action == 'getDealerName') {

            $sales_ref_id = $request->input('sales_ref_id');

            $dealer_name = DealerCreation::select('id', 'dealer_name')->where(function ($query) {
                $query->where('delete_status', '0')->orWhereNull('delete_status');
            })->orderBy('dealer_name');

            if (!empty($sales_ref_id)) {
                $dealer_name->where('sales_rep_id', '=', $sales_ref_id);
            }

            $dealer_name1 = $dealer_name->get();
            return response()->json($dealer_name1);
        }
    }
}
